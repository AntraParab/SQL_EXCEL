USE Week3_DataAnalytics;

-- ============================================
-- TASK 3: GROUP BY
-- Calculate total sales handled by each employee
-- ============================================

SELECT
    EmployeeID,
    COUNT(*) AS TotalOrders,
    SUM(TotalAmount) AS TotalSales
FROM Orders
GROUP BY EmployeeID;


-- ============================================
-- TASK 3: GROUP BY + HAVING
-- Show only employees whose total sales
-- are greater than 50000
-- ============================================

SELECT
    EmployeeID,
    COUNT(*) AS TotalOrders,
    SUM(TotalAmount) AS TotalSales
FROM Orders
GROUP BY EmployeeID
HAVING SUM(TotalAmount) > 50000;