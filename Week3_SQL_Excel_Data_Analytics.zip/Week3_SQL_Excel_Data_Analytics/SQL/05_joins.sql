USE Week3_DataAnalytics;

-- ============================================
-- TASK 4: INNER JOIN
-- Customers who have placed orders
-- ============================================

SELECT
    Customers.CustomerID,
    Customers.CustomerName,
    Orders.OrderID,
    Orders.OrderDate,
    Orders.TotalAmount
FROM Customers
INNER JOIN Orders
    ON Customers.CustomerID = Orders.CustomerID;


-- ============================================
-- TASK 4: LEFT JOIN
-- Show all customers and their orders
-- ============================================

SELECT
    Customers.CustomerID,
    Customers.CustomerName,
    Orders.OrderID,
    Orders.OrderDate,
    Orders.TotalAmount
FROM Customers
LEFT JOIN Orders
    ON Customers.CustomerID = Orders.CustomerID;


-- ============================================
-- TASK 4: RIGHT JOIN
-- Show all orders and their matching customers
-- ============================================

SELECT
    Customers.CustomerID,
    Customers.CustomerName,
    Orders.OrderID,
    Orders.OrderDate,
    Orders.TotalAmount
FROM Customers
RIGHT JOIN Orders
    ON Customers.CustomerID = Orders.CustomerID;