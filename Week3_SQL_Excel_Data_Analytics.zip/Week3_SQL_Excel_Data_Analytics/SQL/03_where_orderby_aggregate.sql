USE Week3_DataAnalytics;

-- WHERE clause
SELECT *
FROM Employees
WHERE Salary > 50000;

-- Comparison operator
SELECT *
FROM Products
WHERE Price >= 10000;

-- ORDER BY
SELECT *
FROM Employees
ORDER BY Salary DESC;

-- COUNT()
SELECT COUNT(*) AS TotalEmployees
FROM Employees;

-- SUM()
SELECT SUM(Salary) AS TotalSalary
FROM Employees;

-- AVG()
SELECT AVG(Salary) AS AverageSalary
FROM Employees;

-- MIN()
SELECT MIN(Salary) AS MinimumSalary
FROM Employees;

-- MAX()
SELECT MAX(Salary) AS MaximumSalary
FROM Employees;