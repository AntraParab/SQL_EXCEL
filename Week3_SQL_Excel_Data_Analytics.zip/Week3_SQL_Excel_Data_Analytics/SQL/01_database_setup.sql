-- ============================================
-- WEEK 3 SQL & EXCEL DATA ANALYTICS
-- DATABASE SETUP
-- ============================================

DROP DATABASE IF EXISTS Week3_DataAnalytics;

CREATE DATABASE Week3_DataAnalytics;

USE Week3_DataAnalytics;


-- ============================================
-- TABLE 1: CUSTOMERS
-- ============================================

CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    CustomerName VARCHAR(100),
    City VARCHAR(50),
    Email VARCHAR(100)
);


-- ============================================
-- TABLE 2: PRODUCTS
-- ============================================

CREATE TABLE Products (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(100),
    Category VARCHAR(50),
    Price DECIMAL(10,2)
);


-- ============================================
-- TABLE 3: EMPLOYEES
-- ============================================

CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY,
    EmployeeName VARCHAR(100),
    Department VARCHAR(50),
    Salary DECIMAL(10,2)
);


-- ============================================
-- TABLE 4: ORDERS
-- ============================================

CREATE TABLE Orders (
    OrderID INT PRIMARY KEY,
    CustomerID INT,
    ProductID INT,
    EmployeeID INT,
    Quantity INT,
    OrderDate DATE,
    TotalAmount DECIMAL(10,2),

    FOREIGN KEY (CustomerID)
        REFERENCES Customers(CustomerID),

    FOREIGN KEY (ProductID)
        REFERENCES Products(ProductID),

    FOREIGN KEY (EmployeeID)
        REFERENCES Employees(EmployeeID)
);


-- ============================================
-- INSERT CUSTOMERS
-- ============================================

INSERT INTO Customers
(CustomerID, CustomerName, City, Email)
VALUES
(1, 'Aarav Sharma', 'Mumbai', 'aarav@gmail.com'),
(2, 'Priya Patel', 'Pune', 'priya@gmail.com'),
(3, 'Rahul Mehta', 'Mumbai', 'rahul@gmail.com'),
(4, 'Sneha Shah', 'Delhi', 'sneha@gmail.com'),
(5, 'Aditya Rao', 'Bangalore', 'aditya@gmail.com'),
(6, 'Neha Joshi', 'Mumbai', 'neha@gmail.com'),
(7, 'Rohan Desai', 'Pune', 'rohan@gmail.com'),
(8, 'Ananya Singh', 'Delhi', 'ananya@gmail.com');


-- ============================================
-- INSERT PRODUCTS
-- ============================================

INSERT INTO Products
(ProductID, ProductName, Category, Price)
VALUES
(101, 'Laptop', 'Electronics', 65000),
(102, 'Smartphone', 'Electronics', 35000),
(103, 'Headphones', 'Accessories', 2500),
(104, 'Keyboard', 'Accessories', 1500),
(105, 'Monitor', 'Electronics', 18000),
(106, 'Mouse', 'Accessories', 900);


-- ============================================
-- INSERT EMPLOYEES
-- ============================================

INSERT INTO Employees
(EmployeeID, EmployeeName, Department, Salary)
VALUES
(201, 'Amit Kumar', 'Sales', 45000),
(202, 'Pooja Verma', 'Sales', 52000),
(203, 'Karan Shah', 'IT', 70000),
(204, 'Nisha Patel', 'HR', 48000),
(205, 'Vikas Rao', 'Sales', 60000),
(206, 'Meera Joshi', 'IT', 75000);


-- ============================================
-- INSERT ORDERS
-- ============================================

INSERT INTO Orders
(OrderID, CustomerID, ProductID, EmployeeID, Quantity, OrderDate, TotalAmount)
VALUES
(1001, 1, 101, 201, 1, '2026-01-05', 65000),
(1002, 2, 102, 202, 2, '2026-01-07', 70000),
(1003, 3, 103, 201, 3, '2026-01-10', 7500),
(1004, 4, 105, 205, 1, '2026-01-12', 18000),
(1005, 5, 104, 202, 2, '2026-01-15', 3000),
(1006, 6, 101, 205, 1, '2026-01-18', 65000),
(1007, 7, 106, 201, 4, '2026-01-20', 3600),
(1008, 8, 102, 205, 1, '2026-01-22', 35000),
(1009, 1, 105, 202, 2, '2026-01-25', 36000),
(1010, 3, 103, 201, 2, '2026-01-27', 5000);


-- ============================================
-- VERIFY DATABASE
-- ============================================

SHOW TABLES;

SELECT * FROM Customers;

SELECT * FROM Products;

SELECT * FROM Employees;

SELECT * FROM Orders;