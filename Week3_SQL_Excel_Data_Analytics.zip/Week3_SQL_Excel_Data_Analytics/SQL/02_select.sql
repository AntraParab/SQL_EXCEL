USE Week3_DataAnalytics;

-- Task 1: Display all records
SELECT *
FROM Customers;

-- Task 1: Select specific columns
SELECT CustomerName, City
FROM Customers;

-- Task 1: Column aliases
SELECT
    CustomerName AS Customer,
    City AS Location
FROM Customers;