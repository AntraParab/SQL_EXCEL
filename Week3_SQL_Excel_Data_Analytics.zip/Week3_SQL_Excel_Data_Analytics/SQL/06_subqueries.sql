USE Week3_DataAnalytics;

-- ============================================
-- TASK 5: SUBQUERY 1
-- Employees earning more than average salary
-- ============================================

SELECT
    EmployeeID,
    EmployeeName,
    Department,
    Salary
FROM Employees
WHERE Salary > (
    SELECT AVG(Salary)
    FROM Employees
);


-- ============================================
-- TASK 5: SUBQUERY 2
-- Products costing more than average price
-- ============================================

SELECT
    ProductID,
    ProductName,
    Category,
    Price
FROM Products
WHERE Price > (
    SELECT AVG(Price)
    FROM Products
);